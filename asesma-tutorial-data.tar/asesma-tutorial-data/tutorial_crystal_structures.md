# Visualizing crystal structures

In input files for DFT calculations, crystal structures are represented through their lattice parameters and the coordinates of individual atoms. On the other hand, visualizing these structures allows for much more insight into the actual spatial arrangement of the atoms.

We will use two programs, XCrySDen and VESTA, to visualize crystal structures. While XCrySDen has the ability to directly read input and output files from Quantum ESPRESSO, I personally find it easier to produce high-quality figures using VESTA, for which the input files have to be converted into a format the program can read.

## XCrySDen 

- Start XCrySDen through the command line: type `xcrysden` and press enter.
- Load the crystal structure for PbTiO3, using the pw.x input format in the file menu.
- Have a look at atom info, distances, angles, using the buttons at the bottom of the screen.
  - Exercise: What is the coordination of Ti? Find the distances between Ti and O. Are they all the same?
- k-path information: Tools -> k-path
- Export to xsf, in the file menu.

## VESTA

Make sure that VESTA is installed. Type `VESTA` in the command line and press enter. If this gives an error message, we have to download the software. Link: ...
(Extract the archive and click on the "VESTA" file in the folder.)

First, let's have a look at the crystal structure.
- Load xsf
- Distances, angles again: Buttons on the left side of the screen.
- Bonds, polyhedra: Edit->Bonds.
- Modify plot boundaries: Objects->Boundaries.
- Show information about unit cell, atoms: Edit->Edit data->Unit cell.
- Save plots to png: File->Export raster image.

Now, let's visualize the charge density, which was calculated using Quantum ESPRESSO.
- Load cube file
- Modify isosurface value: Objects->Properties->Isosurfaces.
- 2D plot: Utilities->2D Data Display.

### Exercise: Pick a crystal structure from the "library" and visualize it.
- Elements?
- Coordination polyhedra?
- How are they connected?

### Converting crystal structures from one format into another

You can use the tool at https://github.com/fthoele/crystal_structure_converter to convert structures from one format into another. The program uses the "Atomic Simulation Environment" (ASE) python package.

How to use:
- Download archive and extract: [https://github.com/fthoele/crystal_structure_converter/archive/master.zip](https://github.com/fthoele/crystal_structure_converter/archive/master.zip)
- run `pip install .` in the folder with the extracted files
- run `convert_structure.py --in <input_file> --out <output_file> --from espresso-in --to cif`